The content can be downloaded under the following Link:
https://heibox.uni-heidelberg.de/d/8c15d8e8c5424961bd4e/
