The content can be downloaded under the following Link:
https://heibox.uni-heidelberg.de/d/c67db8fa39474c13a5c9/
