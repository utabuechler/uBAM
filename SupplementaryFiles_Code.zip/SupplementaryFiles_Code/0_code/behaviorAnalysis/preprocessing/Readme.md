Preprocessing the raw video to produce the sequence format needed for training the model.
