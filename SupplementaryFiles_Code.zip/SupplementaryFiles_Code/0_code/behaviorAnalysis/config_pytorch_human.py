import os
home = os.path.expanduser("..")

_project=project='humans'
_input_path = home+'/resources/'

results_path = home+'/output/'
_output_path = home+'/output/'

###########################
# data configurations
###########################
crops_path  = _input_path+_project+'/data/'
frames_path = _input_path+_project+'/data/'
detection_file = _input_path+_project+'/detections_time_cohort_utf8.csv'

video_path = _input_path+_project+'/data/'
video_format = 'MTS'
preprocessing_path = _input_path+project+'/preprocessing/'

###########################
# network configurations
###########################
###default values, no need to change
net_name = 'lstm_walking'
features_path = _input_path+_project+'/features/'

checkpoint_path = _input_path+_project+'/features/'
final_weights = checkpoint_path+'lstm_checkpoint.pth.tar'

input_img_size = 227
seq_len = 8

gpu_id = 0
init_weights = _input_path+_project+'/features/'
batchsize_train = 6
batchsize_test  = 6
lr = 0.01#base learning rate
input_img_size = 227#width and size of the images as input to the network
optimizer='SGD'#SGD or Adam
seq_len = 8
skip_frames =  5#in case there is only little movement between consecutive frames, this option allows to set how many frames should be skipped,
                #i.e. if skip_frames=1, 1 frame is skipped, so only every second frame is chosen (frame 0,2,4,6 etc)

#parameters for solver
train_display_freq = 1#frequency of outputs during training
train_nr_epochs = 500#number of epochs
train_checkpoint_freq = 1000#frequency of saving snapshots
train_stepsize = 25000#frequency of changing the learning rate


##############################
# For Generative Model (VAE)
##############################
vae_weights_path = _input_path+_project+'/magnification/'
encode_dim = 20

##############################
# For the text
##############################
RED   = '\033[91m'
END   = '\033[0m'
