transform the pyqt4-designer file (.ui) to a python file (.py):

pyuic5 design.ui -o design.py