This folder "Similarity" holds the script which are based only on features similarity, without classifiers. Labels are used only in "sequencesProjection2D.py" for color coding of the samples in the plot.

Covers the experiments:
- Nearest Neighbors figure 2
- 2D projection, figure 3A
